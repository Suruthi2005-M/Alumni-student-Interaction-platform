const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const cors = require('cors');
const path = require('path');

// Initialize express app
const app = express();
const port = 5000;

// Enable CORS to allow frontend requests
app.use(cors());

// Middleware to parse JSON data
app.use(express.json());

// Set up file upload (photo storage)
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Save uploaded files to the "uploads" folder
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); // Name the file with timestamp
    }
});
const upload = multer({ storage: storage });

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/alumniDB', {
    // useNewUrlParser: true,
    // useUnifiedTopology: true,
}).then(() => {
    console.log('Connected to MongoDB');
}).catch(err => {
    console.error('Failed to connect to MongoDB:', err);
});

// Define Mongoose schema for alumni data
const alumniSchema = new mongoose.Schema({
    rollNo: {type: String, required: true, unique: true},
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String },
    graduationYear: { type: Number },
    degree: { type: String },
    department: { type: String },
    currentJob: { type: String },
    company: { type: String },
    linkedin: { type: String },
    location: { type: String },
    bio: { type: String },
    photo: { type: String }, // Store the photo URL or file path
});

// Create Mongoose model for alumni
const Alumni = mongoose.model('Alumni', alumniSchema);

// Handle form data submission (POST)
app.post('/submitAluminiData', upload.single('photo'), async (req, res) => {
    try {
        const alumniData = {
            rollNo: req.body.rollNo,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            phone: req.body.phone,
            graduationYear: req.body.graduationYear,
            degree: req.body.degree,
            department: req.body.department,
            currentJob: req.body.currentJob,
            company: req.body.company,
            linkedin: req.body.linkedin,
            location: req.body.location,
            bio: req.body.bio,
            photo: req.file ? req.file.path : '', // Save the photo file path if it exists
        };

        const newAlumni = new Alumni(alumniData);
        await newAlumni.save();

        res.status(200).json({ message: 'Alumni data saved successfully!' });
    } catch (error) {
        console.error('Error saving data to MongoDB:', error);
        res.status(500).json({ message: 'Failed to save data', error: error.message });
    }
});
// Fetch all alumni data
app.get('/getAlumniData', async (req, res) => {
    try {
        const alumni = await Alumni.find();
        res.status(200).json(alumni);
    } catch (error) {
        console.error('Error fetching alumni data:', error);
        res.status(500).json({ message: 'Failed to retrieve alumni data' });
    }
});
app.put('/updateAlumni/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const updatedData = req.body;

        const updatedAlumni = await Alumni.findByIdAndUpdate(id, updatedData, { new: true });

        if (!updatedAlumni) return res.status(404).json({ message: 'Alumni not found' });

        res.status(200).json({ message: 'Alumni details updated successfully', data: updatedAlumni });
    } catch (error) {
        console.error('Error updating alumni:', error);
        res.status(500).json({ message: 'Failed to update alumni details', error: error.message });
    }
});


// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
